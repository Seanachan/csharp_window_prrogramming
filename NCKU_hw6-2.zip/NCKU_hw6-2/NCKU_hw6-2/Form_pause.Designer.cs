﻿namespace NCKU_hw6_2
{
    partial class Form_pause
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.startGame = new System.Windows.Forms.Button();
            this.quitGame = new System.Windows.Forms.Button();
            this.openSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // startGame
            // 
            this.startGame.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.startGame.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.startGame.Location = new System.Drawing.Point(353, 363);
            this.startGame.Name = "startGame";
            this.startGame.Size = new System.Drawing.Size(249, 46);
            this.startGame.TabIndex = 9;
            this.startGame.Text = "開始游戲";
            this.startGame.UseVisualStyleBackColor = false;
            // 
            // quitGame
            // 
            this.quitGame.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.quitGame.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.quitGame.Location = new System.Drawing.Point(353, 522);
            this.quitGame.Name = "quitGame";
            this.quitGame.Size = new System.Drawing.Size(249, 46);
            this.quitGame.TabIndex = 11;
            this.quitGame.Text = "離開游戲";
            this.quitGame.UseVisualStyleBackColor = false;
            // 
            // openSave
            // 
            this.openSave.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.openSave.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.openSave.Location = new System.Drawing.Point(353, 443);
            this.openSave.Name = "openSave";
            this.openSave.Size = new System.Drawing.Size(249, 46);
            this.openSave.TabIndex = 10;
            this.openSave.Text = "開啓存檔";
            this.openSave.UseVisualStyleBackColor = false;
            // 
            // Form_pause
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(960, 734);
            this.Controls.Add(this.startGame);
            this.Controls.Add(this.quitGame);
            this.Controls.Add(this.openSave);
            this.Name = "Form_pause";
            this.Text = "Form_pause";
            this.Load += new System.EventHandler(this.Form_pause_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button startGame;
        private System.Windows.Forms.Button quitGame;
        private System.Windows.Forms.Button openSave;
    }
}