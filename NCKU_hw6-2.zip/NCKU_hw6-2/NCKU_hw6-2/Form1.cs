﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;
using System.Data.Common;


namespace NCKU_hw6_2
{
    public partial class Form1 : Form
    {
        private const int blockSize = 64;
        private const int rows = 15;
        private const int columns = 30;
        private Panel hotbar;
        private Panel blockPanel;
        public Image img_grass, img_dirt, img_stone;
        public Steve steve;
        public static BlockType selectedBlock;
        private Vector2F _playerPosition;
        private Panel pausePanel = new Panel();
        private bool mapInitialized = false;
        //private Point steveMapPosition = new Point(5 * blockSize, 3 * blockSize); // Set based on your grid layout

        public enum BlockType
        {
            Grass,
            Dirt,
            Stone,
            Air //no block
        }
        public Form1()
        {
            InitializeComponent();
            this.KeyPreview = true;
            this.Controls.Add(pausePanel);
            pausePanel.Controls.Add(resumeGame);
            pausePanel.Controls.Add(save_and_backhome);
            pausePanel.Size = new Size(978, 781);

            stevePanel.BackColor = Color.Transparent;
            pictureBox1.BackColor= Color.Transparent;
            setVisibleGame(false);
            setVisibleHome(true);
            setVisiblePause(false);
            setScrollBar();
            //setMap();
            setFlowLayout();
            this.BackgroundImage = Image.FromFile("background.jpg");
            this.BackgroundImageLayout = ImageLayout.Stretch;
            img_grass = Image.FromFile("img_grass.png"); img_dirt = Image.FromFile("img_dirt.png"); img_stone = Image.FromFile("img_stone.png");
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void setFlowLayout()
        {
            flowLayoutPanel1.Visible = false;
            flowLayoutPanel1.AutoSize=false;
            flowLayoutPanel1.BackColor = Color.Transparent;
            flowLayoutPanel1.Location = new Point(this.ClientSize.Height-flowLayoutPanel1.Size.Height*2, this.ClientSize.Width/2);
            flowLayoutPanel1.Location = new Point(this.ClientSize.Width/2-flowLayoutPanel1.Width/2, this.ClientSize.Height-3*flowLayoutPanel1.Height);
            flowLayoutPanel1.Size = new Size(blockSize*5, blockSize+5);
        }
        private void removeMap()
        {
            for (int i = 0; i<rows; i++)
            {
                for (int j = 0; j<columns; j++)
                {
                    Control controlToRemove = map.GetControlFromPosition(j, i);
                    map.Controls.Remove(controlToRemove);
                }
            }
        }
        private void setMap()
        {
            mapInitialized = true;
            map.BackColor = Color.Gray;
            for (int i = 0; i<rows; i++)
            {
                for (int j = 0; j<columns; j++)
                {
                    if (i>9)
                    {
                        Block newBlock = new Block(BlockType.Stone);
                        map.Controls.Add(newBlock, j, i);
                    }
                    else if (i>6)
                    {
                        Block newBlock = new Block(BlockType.Dirt);
                        map.Controls.Add(newBlock, j, i);
                    }
                    else if (i>5)
                    {
                        Block newBlock = new Block(BlockType.Grass);
                        map.Controls.Add(newBlock, j, i);
                    }
                    else
                    {
                        Block newBlock = new Block(BlockType.Air);
                        map.Controls.Add(newBlock, j, i);
                    }
                }
            }
        }
        private void setScrollBar()
        {
            hScrollBar1.Size = new Size(this.ClientSize.Width, 25);
            vScrollBar1.Size = new Size(25, this.ClientSize.Height);
            hScrollBar1.Location = new Point(0, this.ClientSize.Height-hScrollBar1.Height);
            vScrollBar1.Location = new Point(this.ClientSize.Width-vScrollBar1.Width, 0);

            hScrollBar1.Maximum = blockSize*29-this.ClientSize.Width-40;
            vScrollBar1.Maximum=blockSize*14-this.ClientSize.Height-3;
        }
        private void AddSteve()
        {
            steve = new Steve();
            stevePanel.Size = new Size(steve.Width, steve.Height);
            stevePanel.Location = new Point(5, blockSize*3-9);
            //_playerPosition=  new Vector2F(5, blockSize*3-9);
            stevePanel.Controls.Add(steve);
            steve.BringToFront();
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            map.Left = -hScrollBar1.Value;
            UpdateStevePosition();
        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            map.Top = -vScrollBar1.Value;
            UpdateStevePosition();
        }

        private void SetupHotbar()
        {
            FlowLayoutPanel hotbar = new FlowLayoutPanel
            {
                Height = blockSize+2,
                Width = blockSize*9,
                BackColor = Color.Transparent,
                //Dock = DockStyle.Bottom,
                //BorderStyle = BorderStyle.FixedSingle
            };

            // Create buttons for each block type
            Button grassButton = new Button { Text = "Grass", BackgroundImage=img_grass, Size = new Size(blockSize, blockSize) };
            Button dirtButton = new Button { Text = "Dirt", BackgroundImage=img_dirt, Size = new Size(blockSize, blockSize) };
            Button stoneButton = new Button { Text = "Stone", BackgroundImage=img_stone, Size = new Size(blockSize, blockSize) };

            // Hook up event handlers to set the selected block type
            grassButton.Click += (s, e) => selectedBlock = (BlockType.Grass);
            dirtButton.Click += (s, e) => selectedBlock = (BlockType.Dirt);
            stoneButton.Click += (s, e) => selectedBlock = (BlockType.Stone);

            // Add buttons to hotbar panel
            hotbar.Controls.Add(grassButton);
            hotbar.Controls.Add(dirtButton);
            hotbar.Controls.Add(stoneButton);

            // Add hotbar to form
            flowLayoutPanel1.Controls.Add(hotbar);
        }
        private void UpdateStevePosition()
        {
            // Set Steve's position based on map location and an offset
            int xOffset = map.Left + (5); // Assuming Steve is in the 5th column
            int yOffset = map.Top + (3 * blockSize-9); // Assuming Steve is in the 3rd row

            stevePanel.Location = new Point(xOffset, yOffset);
        }
        private void setVisibleGame(bool visible)
        {
            if (visible)
            {
                map.Visible = true;
                vScrollBar1.Visible= true;
                hScrollBar1.Visible= true;
                stevePanel.Visible= true;
                flowLayoutPanel1.Visible = true;
            }
            else
            {
                map.Visible = false;
                vScrollBar1.Visible= false;
                hScrollBar1.Visible= false;
                stevePanel.Visible= false;
                flowLayoutPanel1.Visible = false;
            }
        }
        private void setVisibleHome(bool b)
        {
            if (b)
            {
                startGame.Visible = true;
                startGame.Visible = true;
                quitGame.Visible = true;
                openSave.Visible =true;
                pictureBox1.Visible = true;
                this.BackgroundImage=Image.FromFile("background.jpg");
                this.BackColor = Color.DarkGray;
            }
            else
            {
                startGame.Visible = false;
                startGame.Visible = false;
                quitGame.Visible = false ;
                openSave.Visible =false;
                pictureBox1.Visible = false;
                this.BackgroundImage=null;
                this.BackColor = Color.DarkGray;
            }
        }

        private void setVisiblePause(bool visible)
        {
            if (visible)
            {
                resumeGame.Visible = true;
                save_and_backhome.Visible = true;
                pausePanel.Visible = true;
                pausePanel.BringToFront();
            }
            else
            {
                resumeGame.Visible = false;
                save_and_backhome.Visible = false;
                pausePanel.Visible = false;
            }
        }
        private void openSave_Click(object sender, EventArgs e)
        {
            if(!mapInitialized) setMap();
            setVisibleHome(false);
            setVisibleGame(true);
            AddSteve();
            SetupHotbar();
        }

        private void quitGame_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void resumeGame_Click(object sender, EventArgs e)
        {
            setVisiblePause(false);
        }

        private void save_and_backhome_Click(object sender, EventArgs e)
        {
            setVisiblePause(false);
            setVisibleGame(false);
            setVisibleHome(true);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

            if(this.BackgroundImage==null&& e.KeyCode == Keys.Escape)
            {
                pausePanel.BackColor = Color.FromArgb(128,Color.Black);
                setVisiblePause(true);
            }
        }

        private void startGame_Click(object sender, EventArgs e)
        {

            if(!mapInitialized)setMap();
            else
            {
                removeMap();
                setMap();
            }
            setVisibleHome(false);
            setVisibleGame(true);
            AddSteve();
            SetupHotbar();
        }
    }
}
